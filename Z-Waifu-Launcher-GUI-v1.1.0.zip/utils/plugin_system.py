#!/usr/bin/env python3
"""
Z-Waifu Launcher GUI - Plugin System
Extensible architecture for custom features and plugins.
"""

import os
import sys
import json
import importlib
import importlib.util
import threading
import time
from datetime import datetime
from typing import Dict, List, Any, Optional, Callable
import logging

# Add the parent directory to the path so we can import the launcher
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from zwaifu_launcher_gui import LauncherGUI, TerminalEmulator
except ImportError:
    print("Error: Could not import launcher modules")
    sys.exit(1)

class PluginBase:
    """Base class for all plugins"""
    
    def __init__(self, launcher_gui: LauncherGUI):
        self.launcher_gui = launcher_gui
        self.name = "Base Plugin"
        self.version = "1.0.0"
        self.description = "Base plugin class"
        self.author = "Unknown"
        self.enabled = False
        self.config = {}
        self.logger = logging.getLogger(f"plugin.{self.name}")
    
    def initialize(self) -> bool:
        """Initialize the plugin"""
        self.logger.info(f"Initializing plugin: {self.name}")
        return True
    
    def enable(self) -> bool:
        """Enable the plugin"""
        self.enabled = True
        self.logger.info(f"Enabled plugin: {self.name}")
        return True
    
    def disable(self) -> bool:
        """Disable the plugin"""
        self.enabled = False
        self.logger.info(f"Disabled plugin: {self.name}")
        return True
    
    def cleanup(self) -> bool:
        """Cleanup plugin resources"""
        self.logger.info(f"Cleaning up plugin: {self.name}")
        return True
    
    def get_config(self) -> Dict[str, Any]:
        """Get plugin configuration"""
        return self.config
    
    def set_config(self, config: Dict[str, Any]) -> bool:
        """Set plugin configuration"""
        self.config = config
        return True
    
    def on_process_start(self, process_type: str, instance_id: int) -> None:
        """Called when a process starts"""
        pass
    
    def on_process_stop(self, process_type: str, instance_id: int) -> None:
        """Called when a process stops"""
        pass
    
    def on_process_error(self, process_type: str, instance_id: int, error: str) -> None:
        """Called when a process encounters an error"""
        pass
    
    def on_config_change(self, config: Dict[str, Any]) -> None:
        """Called when launcher configuration changes"""
        pass
    
    def on_launcher_start(self) -> None:
        """Called when launcher starts"""
        pass
    
    def on_launcher_stop(self) -> None:
        """Called when launcher stops"""
        pass

class PluginManager:
    """Manages plugin loading, enabling, and lifecycle"""
    
    def __init__(self, launcher_gui: LauncherGUI):
        self.launcher_gui = launcher_gui
        self.plugins: Dict[str, PluginBase] = {}
        self.plugin_configs: Dict[str, Dict[str, Any]] = {}
        self.plugin_dir = os.path.join(os.path.dirname(__file__), 'plugins')
        self.config_file = os.path.join(os.path.dirname(__file__), 'plugin_config.json')
        
        # Create plugin directory if it doesn't exist
        os.makedirs(self.plugin_dir, exist_ok=True)
        
        # Setup logging
        self.logger = logging.getLogger('plugin_manager')
        
        # Load plugin configurations
        self.load_plugin_configs()
        
        # Auto-discovery and loading
        self.discover_plugins()
    
    def load_plugin_configs(self) -> None:
        """Load plugin configurations from file"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    self.plugin_configs = json.load(f)
            else:
                self.plugin_configs = {}
        except Exception as e:
            self.logger.error(f"Error loading plugin configs: {e}")
            self.plugin_configs = {}
    
    def save_plugin_configs(self) -> None:
        """Save plugin configurations to file"""
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self.plugin_configs, f, indent=2)
        except Exception as e:
            self.logger.error(f"Error saving plugin configs: {e}")
    
    def discover_plugins(self) -> None:
        """Discover and load available plugins"""
        self.logger.info("Discovering plugins...")
        
        # Look for plugin files in the plugin directory
        for filename in os.listdir(self.plugin_dir):
            if filename.endswith('.py') and not filename.startswith('__'):
                plugin_name = filename[:-3]  # Remove .py extension
                plugin_path = os.path.join(self.plugin_dir, filename)
                
                try:
                    self.load_plugin(plugin_name, plugin_path)
                except Exception as e:
                    self.logger.error(f"Error loading plugin {plugin_name}: {e}")
    
    def load_plugin(self, plugin_name: str, plugin_path: str) -> bool:
        """Load a plugin from file"""
        try:
            # Load the plugin module
            spec = importlib.util.spec_from_file_location(plugin_name, plugin_path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            
            # Find plugin class (should inherit from PluginBase)
            plugin_class = None
            for attr_name in dir(module):
                attr = getattr(module, attr_name)
                if (isinstance(attr, type) and 
                    issubclass(attr, PluginBase) and 
                    attr != PluginBase):
                    plugin_class = attr
                    break
            
            if plugin_class is None:
                self.logger.warning(f"No plugin class found in {plugin_name}")
                return False
            
            # Create plugin instance
            plugin = plugin_class(self.launcher_gui)
            
            # Load plugin configuration
            if plugin_name in self.plugin_configs:
                plugin.set_config(self.plugin_configs[plugin_name])
            
            # Initialize plugin
            if plugin.initialize():
                self.plugins[plugin_name] = plugin
                self.logger.info(f"Loaded plugin: {plugin.name} v{plugin.version}")
                
                # Auto-enable if configured
                if plugin_name in self.plugin_configs:
                    if self.plugin_configs[plugin_name].get('auto_enable', False):
                        self.enable_plugin(plugin_name)
                
                return True
            else:
                self.logger.error(f"Failed to initialize plugin: {plugin_name}")
                return False
                
        except Exception as e:
            self.logger.error(f"Error loading plugin {plugin_name}: {e}")
            return False
    
    def enable_plugin(self, plugin_name: str) -> bool:
        """Enable a plugin"""
        if plugin_name not in self.plugins:
            self.logger.error(f"Plugin {plugin_name} not found")
            return False
        
        plugin = self.plugins[plugin_name]
        if plugin.enable():
            # Update configuration
            if plugin_name not in self.plugin_configs:
                self.plugin_configs[plugin_name] = {}
            self.plugin_configs[plugin_name]['enabled'] = True
            self.save_plugin_configs()
            
            self.logger.info(f"Enabled plugin: {plugin_name}")
            return True
        else:
            self.logger.error(f"Failed to enable plugin: {plugin_name}")
            return False
    
    def disable_plugin(self, plugin_name: str) -> bool:
        """Disable a plugin"""
        if plugin_name not in self.plugins:
            self.logger.error(f"Plugin {plugin_name} not found")
            return False
        
        plugin = self.plugins[plugin_name]
        if plugin.disable():
            # Update configuration
            if plugin_name in self.plugin_configs:
                self.plugin_configs[plugin_name]['enabled'] = False
                self.save_plugin_configs()
            
            self.logger.info(f"Disabled plugin: {plugin_name}")
            return True
        else:
            self.logger.error(f"Failed to disable plugin: {plugin_name}")
            return False
    
    def unload_plugin(self, plugin_name: str) -> bool:
        """Unload a plugin"""
        if plugin_name not in self.plugins:
            self.logger.error(f"Plugin {plugin_name} not found")
            return False
        
        plugin = self.plugins[plugin_name]
        
        # Disable first
        if plugin.enabled:
            plugin.disable()
        
        # Cleanup
        if plugin.cleanup():
            del self.plugins[plugin_name]
            self.logger.info(f"Unloaded plugin: {plugin_name}")
            return True
        else:
            self.logger.error(f"Failed to unload plugin: {plugin_name}")
            return False
    
    def get_plugin(self, plugin_name: str) -> Optional[PluginBase]:
        """Get a plugin by name"""
        return self.plugins.get(plugin_name)
    
    def get_plugins(self) -> Dict[str, PluginBase]:
        """Get all plugins"""
        return self.plugins.copy()
    
    def get_enabled_plugins(self) -> Dict[str, PluginBase]:
        """Get all enabled plugins"""
        return {name: plugin for name, plugin in self.plugins.items() if plugin.enabled}
    
    def set_plugin_config(self, plugin_name: str, config: Dict[str, Any]) -> bool:
        """Set configuration for a plugin"""
        if plugin_name not in self.plugins:
            self.logger.error(f"Plugin {plugin_name} not found")
            return False
        
        plugin = self.plugins[plugin_name]
        if plugin.set_config(config):
            # Save to file
            self.plugin_configs[plugin_name] = config
            self.save_plugin_configs()
            return True
        else:
            return False
    
    def notify_process_start(self, process_type: str, instance_id: int) -> None:
        """Notify all enabled plugins of process start"""
        for plugin in self.get_enabled_plugins().values():
            try:
                plugin.on_process_start(process_type, instance_id)
            except Exception as e:
                self.logger.error(f"Error in plugin {plugin.name} on_process_start: {e}")
    
    def notify_process_stop(self, process_type: str, instance_id: int) -> None:
        """Notify all enabled plugins of process stop"""
        for plugin in self.get_enabled_plugins().values():
            try:
                plugin.on_process_stop(process_type, instance_id)
            except Exception as e:
                self.logger.error(f"Error in plugin {plugin.name} on_process_stop: {e}")
    
    def notify_process_error(self, process_type: str, instance_id: int, error: str) -> None:
        """Notify all enabled plugins of process error"""
        for plugin in self.get_enabled_plugins().values():
            try:
                plugin.on_process_error(process_type, instance_id, error)
            except Exception as e:
                self.logger.error(f"Error in plugin {plugin.name} on_process_error: {e}")
    
    def notify_config_change(self, config: Dict[str, Any]) -> None:
        """Notify all enabled plugins of configuration change"""
        for plugin in self.get_enabled_plugins().values():
            try:
                plugin.on_config_change(config)
            except Exception as e:
                self.logger.error(f"Error in plugin {plugin.name} on_config_change: {e}")
    
    def notify_launcher_start(self) -> None:
        """Notify all enabled plugins of launcher start"""
        for plugin in self.get_enabled_plugins().values():
            try:
                plugin.on_launcher_start()
            except Exception as e:
                self.logger.error(f"Error in plugin {plugin.name} on_launcher_start: {e}")
    
    def notify_launcher_stop(self) -> None:
        """Notify all enabled plugins of launcher stop"""
        for plugin in self.get_enabled_plugins().values():
            try:
                plugin.on_launcher_stop()
            except Exception as e:
                self.logger.error(f"Error in plugin {plugin.name} on_launcher_stop: {e}")
    
    def cleanup(self) -> None:
        """Cleanup all plugins"""
        self.logger.info("Cleaning up plugin manager...")
        
        for plugin_name, plugin in self.plugins.items():
            try:
                plugin.cleanup()
            except Exception as e:
                self.logger.error(f"Error cleaning up plugin {plugin_name}: {e}")

# Example plugins
class ProcessMonitorPlugin(PluginBase):
    """Plugin for monitoring process performance"""
    
    def __init__(self, launcher_gui: LauncherGUI):
        super().__init__(launcher_gui)
        self.name = "Process Monitor"
        self.version = "1.0.0"
        self.description = "Monitors process performance and logs metrics"
        self.author = "Z-Waifu Team"
        self.monitoring_thread = None
        self.monitoring_active = False
    
    def initialize(self) -> bool:
        """Initialize the plugin"""
        self.config = {
            'monitor_interval': 5,  # seconds
            'log_metrics': True,
            'alert_threshold_cpu': 80,  # percent
            'alert_threshold_memory': 1024  # MB
        }
        return True
    
    def enable(self) -> bool:
        """Enable the plugin"""
        if super().enable():
            self.monitoring_active = True
            self.monitoring_thread = threading.Thread(target=self._monitor_processes, daemon=True)
            self.monitoring_thread.start()
            return True
        return False
    
    def disable(self) -> bool:
        """Disable the plugin"""
        self.monitoring_active = False
        if self.monitoring_thread:
            self.monitoring_thread.join(timeout=5)
        return super().disable()
    
    def _monitor_processes(self) -> None:
        """Monitor process performance"""
        while self.monitoring_active:
            try:
                if hasattr(self.launcher_gui, 'process_instance_tabs'):
                    for process_type, instances in self.launcher_gui.process_instance_tabs.items():
                        for i, instance_data in enumerate(instances):
                            proc = instance_data.get('proc')
                            if proc and proc.poll() is None:
                                try:
                                    p = psutil.Process(proc.pid)
                                    cpu_percent = p.cpu_percent(interval=0.1)
                                    memory_mb = p.memory_info().rss / (1024 * 1024)
                                    
                                    # Check thresholds
                                    if cpu_percent > self.config['alert_threshold_cpu']:
                                        self.logger.warning(f"High CPU usage for {process_type} Instance {i+1}: {cpu_percent:.1f}%")
                                    
                                    if memory_mb > self.config['alert_threshold_memory']:
                                        self.logger.warning(f"High memory usage for {process_type} Instance {i+1}: {memory_mb:.1f} MB")
                                    
                                    if self.config['log_metrics']:
                                        self.logger.info(f"{process_type} Instance {i+1}: CPU {cpu_percent:.1f}%, Memory {memory_mb:.1f} MB")
                                        
                                except Exception as e:
                                    self.logger.error(f"Error monitoring {process_type} Instance {i+1}: {e}")
                
                time.sleep(self.config['monitor_interval'])
                
            except Exception as e:
                self.logger.error(f"Error in process monitoring: {e}")
                time.sleep(10)

class AutoRestartPlugin(PluginBase):
    """Plugin for automatic process restart on failure"""
    
    def __init__(self, launcher_gui: LauncherGUI):
        super().__init__(launcher_gui)
        self.name = "Auto Restart"
        self.version = "1.0.0"
        self.description = "Automatically restarts processes that fail"
        self.author = "Z-Waifu Team"
        self.restart_counts = {}
    
    def initialize(self) -> bool:
        """Initialize the plugin"""
        self.config = {
            'max_restarts': 3,
            'restart_delay': 5,  # seconds
            'restart_window': 300,  # seconds (5 minutes)
            'enabled_processes': ['Oobabooga', 'Z-Waifu', 'Ollama', 'RVC']
        }
        return True
    
    def on_process_error(self, process_type: str, instance_id: int, error: str) -> None:
        """Handle process errors"""
        if process_type not in self.config['enabled_processes']:
            return
        
        key = f"{process_type}_{instance_id}"
        current_time = time.time()
        
        # Initialize restart tracking
        if key not in self.restart_counts:
            self.restart_counts[key] = {'count': 0, 'last_restart': 0}
        
        restart_info = self.restart_counts[key]
        
        # Check if we're within the restart window
        if current_time - restart_info['last_restart'] > self.config['restart_window']:
            restart_info['count'] = 0
        
        # Check if we can restart
        if restart_info['count'] < self.config['max_restarts']:
            restart_info['count'] += 1
            restart_info['last_restart'] = current_time
            
            self.logger.info(f"Auto-restarting {process_type} Instance {instance_id+1} (attempt {restart_info['count']})")
            
            # Schedule restart
            threading.Timer(self.config['restart_delay'], 
                          lambda: self._restart_process(process_type, instance_id)).start()
        else:
            self.logger.error(f"Max restarts reached for {process_type} Instance {instance_id+1}")

class NotificationPlugin(PluginBase):
    """Plugin for system notifications"""
    
    def __init__(self, launcher_gui: LauncherGUI):
        super().__init__(launcher_gui)
        self.name = "Notifications"
        self.version = "1.0.0"
        self.description = "Provides system notifications for events"
        self.author = "Z-Waifu Team"
    
    def initialize(self) -> bool:
        """Initialize the plugin"""
        self.config = {
            'notify_process_start': True,
            'notify_process_stop': True,
            'notify_process_error': True,
            'notify_high_cpu': True,
            'notify_high_memory': True
        }
        return True
    
    def on_process_start(self, process_type: str, instance_id: int) -> None:
        """Handle process start"""
        if self.config['notify_process_start']:
            self._send_notification(f"{process_type} Instance {instance_id+1} started", "info")
    
    def on_process_stop(self, process_type: str, instance_id: int) -> None:
        """Handle process stop"""
        if self.config['notify_process_stop']:
            self._send_notification(f"{process_type} Instance {instance_id+1} stopped", "warning")
    
    def on_process_error(self, process_type: str, instance_id: int, error: str) -> None:
        """Handle process error"""
        if self.config['notify_process_error']:
            self._send_notification(f"{process_type} Instance {instance_id+1} error: {error}", "error")
    
    def _send_notification(self, message: str, level: str) -> None:
        """Send a system notification"""
        try:
            # Try to use Windows toast notifications
            if os.name == 'nt':
                from win10toast import ToastNotifier
                toaster = ToastNotifier()
                toaster.show_toast("Z-Waifu Launcher", message, duration=5)
            else:
                # Fallback to console output
                timestamp = datetime.now().strftime("%H:%M:%S")
                print(f"[{timestamp}] {level.upper()}: {message}")
        except Exception as e:
            self.logger.error(f"Error sending notification: {e}")

def create_plugin_manager(launcher_gui: LauncherGUI) -> PluginManager:
    """Create and initialize plugin manager"""
    try:
        plugin_manager = PluginManager(launcher_gui)
        
        # Create example plugins directory
        plugins_dir = os.path.join(os.path.dirname(__file__), 'plugins')
        os.makedirs(plugins_dir, exist_ok=True)
        
        # Create example plugin files
        create_example_plugins(plugins_dir)
        
        return plugin_manager
    except Exception as e:
        print(f"Error creating plugin manager: {e}")
        return None

def create_example_plugins(plugins_dir: str) -> None:
    """Create example plugin files"""
    
    # Process Monitor Plugin
    monitor_plugin = '''#!/usr/bin/env python3
"""
Process Monitor Plugin
Monitors process performance and logs metrics
"""

import psutil
import threading
import time
from plugin_system import PluginBase

class ProcessMonitorPlugin(PluginBase):
    def __init__(self, launcher_gui):
        super().__init__(launcher_gui)
        self.name = "Process Monitor"
        self.version = "1.0.0"
        self.description = "Monitors process performance and logs metrics"
        self.author = "Z-Waifu Team"
        self.monitoring_thread = None
        self.monitoring_active = False
    
    def initialize(self):
        self.config = {
            'monitor_interval': 5,
            'log_metrics': True,
            'alert_threshold_cpu': 80,
            'alert_threshold_memory': 1024
        }
        return True
    
    def enable(self):
        if super().enable():
            self.monitoring_active = True
            self.monitoring_thread = threading.Thread(target=self._monitor_processes, daemon=True)
            self.monitoring_thread.start()
            return True
        return False
    
    def disable(self):
        self.monitoring_active = False
        if self.monitoring_thread:
            self.monitoring_thread.join(timeout=5)
        return super().disable()
    
    def _monitor_processes(self):
        while self.monitoring_active:
            try:
                if hasattr(self.launcher_gui, 'process_instance_tabs'):
                    for process_type, instances in self.launcher_gui.process_instance_tabs.items():
                        for i, instance_data in enumerate(instances):
                            proc = instance_data.get('proc')
                            if proc and proc.poll() is None:
                                try:
                                    p = psutil.Process(proc.pid)
                                    cpu_percent = p.cpu_percent(interval=0.1)
                                    memory_mb = p.memory_info().rss / (1024 * 1024)
                                    
                                    if cpu_percent > self.config['alert_threshold_cpu']:
                                        self.logger.warning(f"High CPU usage for {process_type} Instance {i+1}: {cpu_percent:.1f}%")
                                    
                                    if memory_mb > self.config['alert_threshold_memory']:
                                        self.logger.warning(f"High memory usage for {process_type} Instance {i+1}: {memory_mb:.1f} MB")
                                    
                                    if self.config['log_metrics']:
                                        self.logger.info(f"{process_type} Instance {i+1}: CPU {cpu_percent:.1f}%, Memory {memory_mb:.1f} MB")
                                        
                                except Exception as e:
                                    self.logger.error(f"Error monitoring {process_type} Instance {i+1}: {e}")
                
                time.sleep(self.config['monitor_interval'])
                
            except Exception as e:
                self.logger.error(f"Error in process monitoring: {e}")
                time.sleep(10)
'''
    
    # Auto Restart Plugin
    restart_plugin = '''#!/usr/bin/env python3
"""
Auto Restart Plugin
Automatically restarts processes that fail
"""

import threading
import time
from plugin_system import PluginBase

class AutoRestartPlugin(PluginBase):
    def __init__(self, launcher_gui):
        super().__init__(launcher_gui)
        self.name = "Auto Restart"
        self.version = "1.0.0"
        self.description = "Automatically restarts processes that fail"
        self.author = "Z-Waifu Team"
        self.restart_counts = {}
    
    def initialize(self):
        self.config = {
            'max_restarts': 3,
            'restart_delay': 5,
            'restart_window': 300,
            'enabled_processes': ['Oobabooga', 'Z-Waifu', 'Ollama', 'RVC']
        }
        return True
    
    def on_process_error(self, process_type, instance_id, error):
        if process_type not in self.config['enabled_processes']:
            return
        
        key = f"{process_type}_{instance_id}"
        current_time = time.time()
        
        if key not in self.restart_counts:
            self.restart_counts[key] = {'count': 0, 'last_restart': 0}
        
        restart_info = self.restart_counts[key]
        
        if current_time - restart_info['last_restart'] > self.config['restart_window']:
            restart_info['count'] = 0
        
        if restart_info['count'] < self.config['max_restarts']:
            restart_info['count'] += 1
            restart_info['last_restart'] = current_time
            
            self.logger.info(f"Auto-restarting {process_type} Instance {instance_id+1} (attempt {restart_info['count']})")
            
            threading.Timer(self.config['restart_delay'], 
                          lambda: self._restart_process(process_type, instance_id)).start()
        else:
            self.logger.error(f"Max restarts reached for {process_type} Instance {instance_id+1}")
    
    def _restart_process(self, process_type, instance_id):
        # Implementation for restarting process
        pass
'''
    
    # Write plugin files
    with open(os.path.join(plugins_dir, 'process_monitor.py'), 'w', encoding='utf-8') as f:
        f.write(monitor_plugin)
    
    with open(os.path.join(plugins_dir, 'auto_restart.py'), 'w', encoding='utf-8') as f:
        f.write(restart_plugin)
    
    # Create __init__.py
    with open(os.path.join(plugins_dir, '__init__.py'), 'w', encoding='utf-8') as f:
        f.write('# Plugin package\n')

if __name__ == "__main__":
    # Test plugin system
    print("Z-Waifu Launcher Plugin System")
    print("This module provides extensible architecture for custom features.")
    print("To use, import and call create_plugin_manager() with your launcher instance.") 