#!/usr/bin/env python3
"""
Z-Waifu Launcher GUI - Advanced Analytics System
Detailed performance metrics and reporting system.
"""

import os
import sys
import json
import threading
import time
import subprocess
import psutil
import sqlite3
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import logging
import csv
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from io import BytesIO
import base64

# Add the parent directory to the path so we can import the launcher
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from zwaifu_launcher_gui import LauncherGUI, TerminalEmulator
except ImportError:
    print("Error: Could not import launcher modules")
    sys.exit(1)

class AnalyticsSystem:
    """Advanced analytics system for performance monitoring and reporting"""
    
    def __init__(self, launcher_gui: LauncherGUI):
        self.launcher_gui = launcher_gui
        self.db_path = os.path.join(os.path.dirname(__file__), 'analytics.db')
        self.logger = logging.getLogger('analytics')
        
        # Initialize database
        self.init_database()
        
        # Analytics configuration
        self.config = {
            'collect_interval': 5,  # seconds
            'retention_days': 30,
            'enable_charts': True,
            'enable_alerts': True,
            'alert_thresholds': {
                'cpu_percent': 80,
                'memory_percent': 80,
                'disk_percent': 90,
                'process_restarts': 5
            }
        }
        
        # Start data collection
        self.collection_active = True
        self.collection_thread = threading.Thread(target=self.collect_metrics, daemon=True)
        self.collection_thread.start()
        
        # Performance history
        self.performance_history = {
            'system': [],
            'processes': {},
            'events': []
        }
    
    def init_database(self):
        """Initialize SQLite database for analytics"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # System metrics table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS system_metrics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    cpu_percent REAL,
                    memory_percent REAL,
                    disk_percent REAL,
                    network_sent REAL,
                    network_recv REAL,
                    temperature REAL
                )
            ''')
            
            # Process metrics table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS process_metrics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    process_type TEXT,
                    instance_id INTEGER,
                    pid INTEGER,
                    cpu_percent REAL,
                    memory_mb REAL,
                    status TEXT,
                    uptime_seconds INTEGER
                )
            ''')
            
            # Events table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    event_type TEXT,
                    process_type TEXT,
                    instance_id INTEGER,
                    message TEXT,
                    severity TEXT
                )
            ''')
            
            # Performance reports table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS performance_reports (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    report_type TEXT,
                    data TEXT,
                    summary TEXT
                )
            ''')
            
            conn.commit()
            conn.close()
            
        except Exception as e:
            self.logger.error(f"Error initializing database: {e}")
    
    def collect_metrics(self):
        """Collect system and process metrics"""
        while self.collection_active:
            try:
                timestamp = datetime.now()
                
                # Collect system metrics
                system_metrics = self.collect_system_metrics()
                self.store_system_metrics(system_metrics)
                
                # Collect process metrics
                process_metrics = self.collect_process_metrics()
                self.store_process_metrics(process_metrics)
                
                # Check for alerts
                if self.config['enable_alerts']:
                    self.check_alerts(system_metrics, process_metrics)
                
                # Update performance history
                self.update_performance_history(system_metrics, process_metrics)
                
                time.sleep(self.config['collect_interval'])
                
            except Exception as e:
                self.logger.error(f"Error collecting metrics: {e}")
                time.sleep(10)
    
    def collect_system_metrics(self) -> Dict[str, Any]:
        """Collect system-level metrics"""
        try:
            # CPU usage
            cpu_percent = psutil.cpu_percent(interval=1)
            
            # Memory usage
            memory = psutil.virtual_memory()
            memory_percent = memory.percent
            
            # Disk usage
            disk = psutil.disk_usage('/')
            disk_percent = disk.percent
            
            # Network usage
            network = psutil.net_io_counters()
            network_sent = network.bytes_sent / (1024 * 1024)  # MB
            network_recv = network.bytes_recv / (1024 * 1024)  # MB
            
            # Temperature (if available)
            temperature = None
            try:
                if hasattr(psutil, 'sensors_temperatures'):
                    temps = psutil.sensors_temperatures()
                    if temps:
                        for name, entries in temps.items():
                            for entry in entries:
                                if entry.current > 0:
                                    temperature = entry.current
                                    break
                            if temperature:
                                break
            except:
                pass
            
            return {
                'timestamp': datetime.now(),
                'cpu_percent': cpu_percent,
                'memory_percent': memory_percent,
                'disk_percent': disk_percent,
                'network_sent': network_sent,
                'network_recv': network_recv,
                'temperature': temperature
            }
            
        except Exception as e:
            self.logger.error(f"Error collecting system metrics: {e}")
            return {}
    
    def collect_process_metrics(self) -> List[Dict[str, Any]]:
        """Collect process-level metrics"""
        metrics = []
        
        try:
            if hasattr(self.launcher_gui, 'process_instance_tabs'):
                for process_type, instances in self.launcher_gui.process_instance_tabs.items():
                    for i, instance_data in enumerate(instances):
                        proc = instance_data.get('proc')
                        terminal = instance_data.get('terminal')
                        
                        metric = {
                            'timestamp': datetime.now(),
                            'process_type': process_type,
                            'instance_id': i,
                            'pid': proc.pid if proc else None,
                            'status': 'Running' if proc and proc.poll() is None else 'Stopped',
                            'cpu_percent': 0,
                            'memory_mb': 0,
                            'uptime_seconds': 0
                        }
                        
                        if proc and proc.poll() is None:
                            try:
                                p = psutil.Process(proc.pid)
                                metric['cpu_percent'] = p.cpu_percent(interval=0.1)
                                metric['memory_mb'] = p.memory_info().rss / (1024 * 1024)
                                
                                if terminal and hasattr(terminal, 'start_time'):
                                    metric['uptime_seconds'] = int(time.time() - terminal.start_time)
                                    
                            except Exception as e:
                                self.logger.error(f"Error collecting metrics for {process_type} Instance {i}: {e}")
                        
                        metrics.append(metric)
            
        except Exception as e:
            self.logger.error(f"Error collecting process metrics: {e}")
        
        return metrics
    
    def store_system_metrics(self, metrics: Dict[str, Any]):
        """Store system metrics in database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO system_metrics 
                (cpu_percent, memory_percent, disk_percent, network_sent, network_recv, temperature)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (
                metrics.get('cpu_percent', 0),
                metrics.get('memory_percent', 0),
                metrics.get('disk_percent', 0),
                metrics.get('network_sent', 0),
                metrics.get('network_recv', 0),
                metrics.get('temperature', 0)
            ))
            
            conn.commit()
            conn.close()
            
        except Exception as e:
            self.logger.error(f"Error storing system metrics: {e}")
    
    def store_process_metrics(self, metrics: List[Dict[str, Any]]):
        """Store process metrics in database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            for metric in metrics:
                cursor.execute('''
                    INSERT INTO process_metrics 
                    (process_type, instance_id, pid, cpu_percent, memory_mb, status, uptime_seconds)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (
                    metric['process_type'],
                    metric['instance_id'],
                    metric['pid'],
                    metric['cpu_percent'],
                    metric['memory_mb'],
                    metric['status'],
                    metric['uptime_seconds']
                ))
            
            conn.commit()
            conn.close()
            
        except Exception as e:
            self.logger.error(f"Error storing process metrics: {e}")
    
    def log_event(self, event_type: str, process_type: str = None, instance_id: int = None, 
                  message: str = "", severity: str = "info"):
        """Log an event to the database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO events (event_type, process_type, instance_id, message, severity)
                VALUES (?, ?, ?, ?, ?)
            ''', (event_type, process_type, instance_id, message, severity))
            
            conn.commit()
            conn.close()
            
        except Exception as e:
            self.logger.error(f"Error logging event: {e}")
    
    def check_alerts(self, system_metrics: Dict[str, Any], process_metrics: List[Dict[str, Any]]):
        """Check for alert conditions"""
        thresholds = self.config['alert_thresholds']
        
        # System alerts
        if system_metrics.get('cpu_percent', 0) > thresholds['cpu_percent']:
            self.log_event('system_alert', message=f"High CPU usage: {system_metrics['cpu_percent']:.1f}%", severity='warning')
        
        if system_metrics.get('memory_percent', 0) > thresholds['memory_percent']:
            self.log_event('system_alert', message=f"High memory usage: {system_metrics['memory_percent']:.1f}%", severity='warning')
        
        if system_metrics.get('disk_percent', 0) > thresholds['disk_percent']:
            self.log_event('system_alert', message=f"High disk usage: {system_metrics['disk_percent']:.1f}%", severity='warning')
        
        # Process alerts
        for metric in process_metrics:
            if metric['status'] == 'Stopped':
                self.log_event('process_alert', metric['process_type'], metric['instance_id'], 
                              f"Process stopped unexpectedly", 'error')
    
    def update_performance_history(self, system_metrics: Dict[str, Any], process_metrics: List[Dict[str, Any]]):
        """Update in-memory performance history"""
        timestamp = datetime.now()
        
        # Update system history
        self.performance_history['system'].append({
            'timestamp': timestamp,
            'metrics': system_metrics
        })
        
        # Keep only last 1000 entries
        if len(self.performance_history['system']) > 1000:
            self.performance_history['system'] = self.performance_history['system'][-1000:]
        
        # Update process history
        for metric in process_metrics:
            key = f"{metric['process_type']}_{metric['instance_id']}"
            if key not in self.performance_history['processes']:
                self.performance_history['processes'][key] = []
            
            self.performance_history['processes'][key].append({
                'timestamp': timestamp,
                'metrics': metric
            })
            
            # Keep only last 1000 entries per process
            if len(self.performance_history['processes'][key]) > 1000:
                self.performance_history['processes'][key] = self.performance_history['processes'][key][-1000:]
    
    def get_system_metrics(self, hours: int = 24) -> List[Dict[str, Any]]:
        """Get system metrics for the specified time period"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cutoff_time = datetime.now() - timedelta(hours=hours)
            
            cursor.execute('''
                SELECT timestamp, cpu_percent, memory_percent, disk_percent, network_sent, network_recv, temperature
                FROM system_metrics
                WHERE timestamp > ?
                ORDER BY timestamp ASC
            ''', (cutoff_time,))
            
            rows = cursor.fetchall()
            conn.close()
            
            return [
                {
                    'timestamp': row[0],
                    'cpu_percent': row[1],
                    'memory_percent': row[2],
                    'disk_percent': row[3],
                    'network_sent': row[4],
                    'network_recv': row[5],
                    'temperature': row[6]
                }
                for row in rows
            ]
            
        except Exception as e:
            self.logger.error(f"Error getting system metrics: {e}")
            return []
    
    def get_process_metrics(self, process_type: str = None, hours: int = 24) -> List[Dict[str, Any]]:
        """Get process metrics for the specified time period"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cutoff_time = datetime.now() - timedelta(hours=hours)
            
            if process_type:
                cursor.execute('''
                    SELECT timestamp, process_type, instance_id, pid, cpu_percent, memory_mb, status, uptime_seconds
                    FROM process_metrics
                    WHERE timestamp > ? AND process_type = ?
                    ORDER BY timestamp ASC
                ''', (cutoff_time, process_type))
            else:
                cursor.execute('''
                    SELECT timestamp, process_type, instance_id, pid, cpu_percent, memory_mb, status, uptime_seconds
                    FROM process_metrics
                    WHERE timestamp > ?
                    ORDER BY timestamp ASC
                ''', (cutoff_time,))
            
            rows = cursor.fetchall()
            conn.close()
            
            return [
                {
                    'timestamp': row[0],
                    'process_type': row[1],
                    'instance_id': row[2],
                    'pid': row[3],
                    'cpu_percent': row[4],
                    'memory_mb': row[5],
                    'status': row[6],
                    'uptime_seconds': row[7]
                }
                for row in rows
            ]
            
        except Exception as e:
            self.logger.error(f"Error getting process metrics: {e}")
            return []
    
    def get_events(self, hours: int = 24, severity: str = None) -> List[Dict[str, Any]]:
        """Get events for the specified time period"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cutoff_time = datetime.now() - timedelta(hours=hours)
            
            if severity:
                cursor.execute('''
                    SELECT timestamp, event_type, process_type, instance_id, message, severity
                    FROM events
                    WHERE timestamp > ? AND severity = ?
                    ORDER BY timestamp DESC
                ''', (cutoff_time, severity))
            else:
                cursor.execute('''
                    SELECT timestamp, event_type, process_type, instance_id, message, severity
                    FROM events
                    WHERE timestamp > ?
                    ORDER BY timestamp DESC
                ''', (cutoff_time,))
            
            rows = cursor.fetchall()
            conn.close()
            
            return [
                {
                    'timestamp': row[0],
                    'event_type': row[1],
                    'process_type': row[2],
                    'instance_id': row[3],
                    'message': row[4],
                    'severity': row[5]
                }
                for row in rows
            ]
            
        except Exception as e:
            self.logger.error(f"Error getting events: {e}")
            return []
    
    def generate_performance_report(self, hours: int = 24) -> Dict[str, Any]:
        """Generate a comprehensive performance report"""
        try:
            system_metrics = self.get_system_metrics(hours)
            process_metrics = self.get_process_metrics(hours=hours)
            events = self.get_events(hours)
            
            # Calculate averages
            if system_metrics:
                avg_cpu = sum(m['cpu_percent'] for m in system_metrics) / len(system_metrics)
                avg_memory = sum(m['memory_percent'] for m in system_metrics) / len(system_metrics)
                avg_disk = sum(m['disk_percent'] for m in system_metrics) / len(system_metrics)
            else:
                avg_cpu = avg_memory = avg_disk = 0
            
            # Process statistics
            process_stats = {}
            for metric in process_metrics:
                key = f"{metric['process_type']}_{metric['instance_id']}"
                if key not in process_stats:
                    process_stats[key] = {
                        'process_type': metric['process_type'],
                        'instance_id': metric['instance_id'],
                        'total_samples': 0,
                        'total_cpu': 0,
                        'total_memory': 0,
                        'max_cpu': 0,
                        'max_memory': 0,
                        'status_changes': 0,
                        'last_status': None
                    }
                
                stats = process_stats[key]
                stats['total_samples'] += 1
                stats['total_cpu'] += metric['cpu_percent']
                stats['total_memory'] += metric['memory_mb']
                stats['max_cpu'] = max(stats['max_cpu'], metric['cpu_percent'])
                stats['max_memory'] = max(stats['max_memory'], metric['memory_mb'])
                
                if stats['last_status'] and stats['last_status'] != metric['status']:
                    stats['status_changes'] += 1
                stats['last_status'] = metric['status']
            
            # Calculate averages for processes
            for key, stats in process_stats.items():
                if stats['total_samples'] > 0:
                    stats['avg_cpu'] = stats['total_cpu'] / stats['total_samples']
                    stats['avg_memory'] = stats['total_memory'] / stats['total_samples']
                else:
                    stats['avg_cpu'] = stats['avg_memory'] = 0
            
            # Event statistics
            event_counts = {}
            for event in events:
                event_type = event['event_type']
                event_counts[event_type] = event_counts.get(event_type, 0) + 1
            
            report = {
                'timestamp': datetime.now().isoformat(),
                'period_hours': hours,
                'system_summary': {
                    'avg_cpu_percent': round(avg_cpu, 2),
                    'avg_memory_percent': round(avg_memory, 2),
                    'avg_disk_percent': round(avg_disk, 2),
                    'total_samples': len(system_metrics)
                },
                'process_summary': list(process_stats.values()),
                'event_summary': {
                    'total_events': len(events),
                    'event_counts': event_counts
                },
                'recommendations': self.generate_recommendations(system_metrics, process_metrics, events)
            }
            
            # Store report
            self.store_performance_report(report)
            
            return report
            
        except Exception as e:
            self.logger.error(f"Error generating performance report: {e}")
            return {'error': str(e)}
    
    def generate_recommendations(self, system_metrics: List[Dict], process_metrics: List[Dict], 
                                events: List[Dict]) -> List[str]:
        """Generate recommendations based on performance data"""
        recommendations = []
        
        if not system_metrics:
            return recommendations
        
        # System recommendations
        avg_cpu = sum(m['cpu_percent'] for m in system_metrics) / len(system_metrics)
        avg_memory = sum(m['memory_percent'] for m in system_metrics) / len(system_metrics)
        
        if avg_cpu > 70:
            recommendations.append("Consider reducing the number of running processes to lower CPU usage")
        
        if avg_memory > 80:
            recommendations.append("High memory usage detected. Consider restarting processes or adding more RAM")
        
        # Process recommendations
        process_restarts = sum(1 for e in events if 'restart' in e['message'].lower())
        if process_restarts > 5:
            recommendations.append("Multiple process restarts detected. Check for stability issues")
        
        # Uptime recommendations
        for metric in process_metrics:
            if metric['uptime_seconds'] > 86400:  # 24 hours
                recommendations.append(f"Consider restarting {metric['process_type']} Instance {metric['instance_id']+1} for maintenance")
        
        return recommendations
    
    def store_performance_report(self, report: Dict[str, Any]):
        """Store performance report in database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO performance_reports (report_type, data, summary)
                VALUES (?, ?, ?)
            ''', (
                'performance_report',
                json.dumps(report),
                f"Performance report for {report['period_hours']} hours"
            ))
            
            conn.commit()
            conn.close()
            
        except Exception as e:
            self.logger.error(f"Error storing performance report: {e}")
    
    def generate_chart(self, chart_type: str, hours: int = 24) -> str:
        """Generate a chart and return as base64 encoded image"""
        if not self.config['enable_charts']:
            return None
        
        try:
            plt.style.use('dark_background')
            fig, ax = plt.subplots(figsize=(10, 6))
            
            if chart_type == 'system_performance':
                system_metrics = self.get_system_metrics(hours)
                if system_metrics:
                    timestamps = [datetime.fromisoformat(m['timestamp']) for m in system_metrics]
                    cpu_values = [m['cpu_percent'] for m in system_metrics]
                    memory_values = [m['memory_percent'] for m in system_metrics]
                    
                    ax.plot(timestamps, cpu_values, label='CPU %', color='#ff6b6b')
                    ax.plot(timestamps, memory_values, label='Memory %', color='#4ecdc4')
                    ax.set_title('System Performance Over Time')
                    ax.set_ylabel('Percentage')
                    ax.legend()
                    ax.grid(True, alpha=0.3)
            
            elif chart_type == 'process_performance':
                process_metrics = self.get_process_metrics(hours=hours)
                if process_metrics:
                    # Group by process type
                    process_data = {}
                    for metric in process_metrics:
                        key = metric['process_type']
                        if key not in process_data:
                            process_data[key] = {'timestamps': [], 'cpu_values': [], 'memory_values': []}
                        
                        process_data[key]['timestamps'].append(datetime.fromisoformat(metric['timestamp']))
                        process_data[key]['cpu_values'].append(metric['cpu_percent'])
                        process_data[key]['memory_values'].append(metric['memory_mb'])
                    
                    colors = ['#ff6b6b', '#4ecdc4', '#45b7d1', '#96ceb4']
                    for i, (process_type, data) in enumerate(process_data.items()):
                        color = colors[i % len(colors)]
                        ax.plot(data['timestamps'], data['cpu_values'], 
                               label=f'{process_type} CPU', color=color, alpha=0.8)
                    
                    ax.set_title('Process CPU Usage Over Time')
                    ax.set_ylabel('CPU %')
                    ax.legend()
                    ax.grid(True, alpha=0.3)
            
            # Format x-axis
            ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M'))
            ax.xaxis.set_major_locator(mdates.HourLocator(interval=max(1, hours//6)))
            plt.xticks(rotation=45)
            
            # Save to base64
            buffer = BytesIO()
            plt.savefig(buffer, format='png', dpi=100, bbox_inches='tight')
            buffer.seek(0)
            image_base64 = base64.b64encode(buffer.getvalue()).decode()
            plt.close()
            
            return f"data:image/png;base64,{image_base64}"
            
        except Exception as e:
            self.logger.error(f"Error generating chart: {e}")
            return None
    
    def export_data(self, format_type: str = 'csv', hours: int = 24) -> str:
        """Export analytics data in specified format"""
        try:
            if format_type == 'csv':
                return self.export_to_csv(hours)
            elif format_type == 'json':
                return self.export_to_json(hours)
            else:
                raise ValueError(f"Unsupported format: {format_type}")
                
        except Exception as e:
            self.logger.error(f"Error exporting data: {e}")
            return None
    
    def export_to_csv(self, hours: int) -> str:
        """Export data to CSV format"""
        try:
            filename = f"analytics_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
            filepath = os.path.join(os.path.dirname(__file__), filename)
            
            with open(filepath, 'w', newline='', encoding='utf-8') as csvfile:
                writer = csv.writer(csvfile)
                
                # Write system metrics
                writer.writerow(['=== SYSTEM METRICS ==='])
                writer.writerow(['Timestamp', 'CPU %', 'Memory %', 'Disk %', 'Network Sent (MB)', 'Network Recv (MB)', 'Temperature'])
                
                system_metrics = self.get_system_metrics(hours)
                for metric in system_metrics:
                    writer.writerow([
                        metric['timestamp'],
                        metric['cpu_percent'],
                        metric['memory_percent'],
                        metric['disk_percent'],
                        metric['network_sent'],
                        metric['network_recv'],
                        metric['temperature']
                    ])
                
                writer.writerow([])
                
                # Write process metrics
                writer.writerow(['=== PROCESS METRICS ==='])
                writer.writerow(['Timestamp', 'Process Type', 'Instance ID', 'PID', 'CPU %', 'Memory (MB)', 'Status', 'Uptime (s)'])
                
                process_metrics = self.get_process_metrics(hours=hours)
                for metric in process_metrics:
                    writer.writerow([
                        metric['timestamp'],
                        metric['process_type'],
                        metric['instance_id'],
                        metric['pid'],
                        metric['cpu_percent'],
                        metric['memory_mb'],
                        metric['status'],
                        metric['uptime_seconds']
                    ])
                
                writer.writerow([])
                
                # Write events
                writer.writerow(['=== EVENTS ==='])
                writer.writerow(['Timestamp', 'Event Type', 'Process Type', 'Instance ID', 'Message', 'Severity'])
                
                events = self.get_events(hours)
                for event in events:
                    writer.writerow([
                        event['timestamp'],
                        event['event_type'],
                        event['process_type'],
                        event['instance_id'],
                        event['message'],
                        event['severity']
                    ])
            
            return filepath
            
        except Exception as e:
            self.logger.error(f"Error exporting to CSV: {e}")
            return None
    
    def export_to_json(self, hours: int) -> str:
        """Export data to JSON format"""
        try:
            filename = f"analytics_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            filepath = os.path.join(os.path.dirname(__file__), filename)
            
            data = {
                'export_timestamp': datetime.now().isoformat(),
                'period_hours': hours,
                'system_metrics': self.get_system_metrics(hours),
                'process_metrics': self.get_process_metrics(hours=hours),
                'events': self.get_events(hours),
                'performance_report': self.generate_performance_report(hours)
            }
            
            with open(filepath, 'w', encoding='utf-8') as jsonfile:
                json.dump(data, jsonfile, indent=2, default=str)
            
            return filepath
            
        except Exception as e:
            self.logger.error(f"Error exporting to JSON: {e}")
            return None
    
    def cleanup_old_data(self):
        """Clean up old data based on retention policy"""
        try:
            cutoff_time = datetime.now() - timedelta(days=self.config['retention_days'])
            
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Delete old system metrics
            cursor.execute('DELETE FROM system_metrics WHERE timestamp < ?', (cutoff_time,))
            
            # Delete old process metrics
            cursor.execute('DELETE FROM process_metrics WHERE timestamp < ?', (cutoff_time,))
            
            # Delete old events
            cursor.execute('DELETE FROM events WHERE timestamp < ?', (cutoff_time,))
            
            # Delete old performance reports (keep last 10)
            cursor.execute('''
                DELETE FROM performance_reports 
                WHERE id NOT IN (
                    SELECT id FROM performance_reports 
                    ORDER BY timestamp DESC 
                    LIMIT 10
                )
            ''')
            
            conn.commit()
            conn.close()
            
            self.logger.info(f"Cleaned up data older than {self.config['retention_days']} days")
            
        except Exception as e:
            self.logger.error(f"Error cleaning up old data: {e}")
    
    def get_analytics_summary(self) -> Dict[str, Any]:
        """Get a quick analytics summary"""
        try:
            # Get last 24 hours of data
            system_metrics = self.get_system_metrics(24)
            process_metrics = self.get_process_metrics(hours=24)
            events = self.get_events(24)
            
            summary = {
                'timestamp': datetime.now().isoformat(),
                'data_points': {
                    'system_metrics': len(system_metrics),
                    'process_metrics': len(process_metrics),
                    'events': len(events)
                },
                'system_health': {
                    'avg_cpu': 0,
                    'avg_memory': 0,
                    'max_cpu': 0,
                    'max_memory': 0
                },
                'process_summary': {},
                'recent_events': events[:10]  # Last 10 events
            }
            
            # Calculate system health
            if system_metrics:
                cpu_values = [m['cpu_percent'] for m in system_metrics]
                memory_values = [m['memory_percent'] for m in system_metrics]
                
                summary['system_health']['avg_cpu'] = round(sum(cpu_values) / len(cpu_values), 2)
                summary['system_health']['avg_memory'] = round(sum(memory_values) / len(memory_values), 2)
                summary['system_health']['max_cpu'] = round(max(cpu_values), 2)
                summary['system_health']['max_memory'] = round(max(memory_values), 2)
            
            # Process summary
            for metric in process_metrics:
                key = f"{metric['process_type']}_{metric['instance_id']}"
                if key not in summary['process_summary']:
                    summary['process_summary'][key] = {
                        'process_type': metric['process_type'],
                        'instance_id': metric['instance_id'],
                        'current_status': metric['status'],
                        'samples': 0
                    }
                summary['process_summary'][key]['samples'] += 1
            
            return summary
            
        except Exception as e:
            self.logger.error(f"Error getting analytics summary: {e}")
            return {'error': str(e)}
    
    def stop(self):
        """Stop the analytics system"""
        self.collection_active = False
        self.cleanup_old_data()
        self.logger.info("Analytics system stopped")

def create_analytics_system(launcher_gui: LauncherGUI) -> AnalyticsSystem:
    """Create and initialize analytics system"""
    try:
        analytics_system = AnalyticsSystem(launcher_gui)
        return analytics_system
    except Exception as e:
        print(f"Error creating analytics system: {e}")
        return None

if __name__ == "__main__":
    # Test analytics system
    print("Z-Waifu Launcher Analytics System")
    print("This module provides advanced performance metrics and reporting.")
    print("To use, import and call create_analytics_system() with your launcher instance.") 