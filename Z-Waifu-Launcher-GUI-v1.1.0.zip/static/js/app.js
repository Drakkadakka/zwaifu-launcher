// Z-Waifu Launcher JavaScript

class LauncherApp {
    constructor() {
        this.socket = null;
        this.init();
    }

    init() {
        this.connectWebSocket();
        this.setupEventListeners();
        this.updateStatus();
    }

    connectWebSocket() {
        try {
            this.socket = io();
            this.socket.on('status_update', (data) => this.updateStatus(data));
            this.socket.on('process_result', (data) => this.handleProcessResult(data));
        } catch (e) {
            console.log('WebSocket not available, using polling');
            setInterval(() => this.updateStatus(), 5000);
        }
    }

    setupEventListeners() {
        document.addEventListener('DOMContentLoaded', () => {
            this.bindButtons();
        });
    }

    bindButtons() {
        document.querySelectorAll('.btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const action = e.target.dataset.action;
                const process = e.target.dataset.process;
                if (action && process) {
                    this.executeAction(action, process);
                }
            });
        });
    }

    executeAction(action, process) {
        if (this.socket) {
            this.socket.emit(action, { process_type: process });
        } else {
            fetch(`/api/${action}/${process}`, { method: 'POST' })
                .then(response => response.json())
                .then(data => this.handleProcessResult(data));
        }
    }

    updateStatus(data) {
        if (!data) {
            fetch('/api/status')
                .then(response => response.json())
                .then(data => this.updateStatus(data));
            return;
        }

        Object.keys(data).forEach(process => {
            const element = document.getElementById(`${process.toLowerCase()}-status`);
            if (element) {
                element.textContent = data[process] ? 'Running' : 'Stopped';
                element.className = `status ${data[process] ? 'running' : 'stopped'}`;
            }
        });
    }

    handleProcessResult(data) {
        if (data.success) {
            this.showNotification('Success', data.message, 'success');
        } else {
            this.showNotification('Error', data.error, 'error');
        }
    }

    showNotification(title, message, type) {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.innerHTML = `
            <h4>${title}</h4>
            <p>${message}</p>
        `;
        document.body.appendChild(notification);
        setTimeout(() => notification.remove(), 3000);
    }
}

// Initialize the app
const app = new LauncherApp();
