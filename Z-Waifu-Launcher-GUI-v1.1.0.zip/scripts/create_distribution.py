#!/usr/bin/env python3
"""
Z-Waifu Launcher GUI - Distribution Creator
This script creates a distributable zip file with all necessary launcher files.
Updated for the new project structure with advanced features.
"""

import os
import zipfile
import shutil
import sys
from datetime import datetime

def create_distribution():
    """Create a distributable zip file with all launcher files"""
    
    # Distribution name and version
    DIST_NAME = "Z-Waifu-Launcher-GUI"
    VERSION = "1.1.0"  # Updated version for new structure
    DIST_FOLDER = f"{DIST_NAME}-v{VERSION}"
    
    # Core files to include in distribution (root level)
    CORE_FILES = [
        "zwaifu_launcher_gui.py",
        "launch_launcher.py", 
        "launch_launcher.bat",
        "README.md",
        "LICENSE",
        "LAUNCHER_README.md"
    ]
    
    # Configuration files
    CONFIG_FILES = [
        "config/requirements.txt",
        "config/VERSION.txt"
    ]
    
    # Documentation files
    DOC_FILES = [
        "docs/README.md",
        "docs/INSTALLATION_GUIDE.md",
        "docs/DISTRIBUTION_GUIDE.md",
        "docs/PROJECT_STRUCTURE.md",
        "docs/CHANGELOG.md",
        "docs/API_DOCUMENTATION.md",
        "docs/PLUGIN_GUIDE.md",
        "docs/INSTALL.txt"
    ]
    
    # Utility files (from utils directory)
    UTILS_FILES = [
        "utils/__init__.py",
        "utils/analytics_system.py",
        "utils/api_server.py",
        "utils/mobile_app.py",
        "utils/plugin_system.py",
        "utils/web_interface.py"
    ]
    
    # Script files (from scripts directory)
    SCRIPT_FILES = [
        "scripts/__init__.py",
        "scripts/create_distribution.py",
        "scripts/create_distribution.bat",
        "scripts/create_launcher_icon.py",
        "scripts/organize_project.py",
        "scripts/install_dependencies.py",
        "scripts/install_dependencies.bat",
        "scripts/setup_venv_and_run_launcher.bat",
        "scripts/launcher.spec",
        "scripts/launch_ooba_zwaifu.bat",
        "scripts/test_launcher.py",
        "scripts/test_advanced_features.py",
        "scripts/test_flash_effect.py",
        "scripts/test_tab_switching.py",
        "scripts/test_theme_toggle.py",
        "scripts/update_flash_calls.py"
    ]
    
    # Plugin files
    PLUGIN_FILES = [
        "plugins/__init__.py",
        "plugins/auto_restart.py",
        "plugins/process_monitor.py",
        "plugins/README.md"
    ]
    
    # Static files (web assets)
    STATIC_FILES = [
        "static/css/style.css",
        "static/js/app.js"
    ]
    
    # Template files
    TEMPLATE_FILES = [
        "templates/dashboard.html",
        "templates/mobile_dashboard.html"
    ]
    
    # AI Tools configuration files
    AI_TOOLS_FILES = [
        "ai_tools/ollama/README.md",
        "ai_tools/oobabooga/README.md",
        "ai_tools/oobabooga/CMD_FLAGS.txt",
        "ai_tools/oobabooga/start_windows - Ooba.lnk",
        "ai_tools/rvc/README.md",
        "ai_tools/zwaifu/README.md"
    ]
    
    # Data files (initial/example data)
    DATA_FILES = [
        "data/launcher_log.txt",
        "data/ooba_log.txt"
    ]
    
    # Optional files (include if they exist)
    OPTIONAL_FILES = [
        "launcher_icon.png",
        "launcher.spec",
        "INSTALL.txt"
    ]
    
    # Directories to include completely
    DIRECTORIES = [
        "utils/",
        "scripts/",
        "config/",
        "docs/",
        "data/",
        "logs/",
        "plugins/",
        "templates/",
        "static/",
        "ai_tools/"
    ]
    
    print(f"Creating distribution: {DIST_NAME} v{VERSION}")
    print("=" * 50)
    
    # Create distribution directory
    if os.path.exists(DIST_FOLDER):
        print(f"Removing existing distribution folder: {DIST_FOLDER}")
        shutil.rmtree(DIST_FOLDER)
    
    os.makedirs(DIST_FOLDER)
    print(f"Created distribution folder: {DIST_FOLDER}")
    
    # Copy core files
    print("\nCopying core files:")
    for file in CORE_FILES:
        if os.path.exists(file):
            shutil.copy2(file, DIST_FOLDER)
            print(f"  ✓ {file}")
        else:
            print(f"  ✗ {file} (not found)")
    
    # Copy configuration files
    print("\nCopying configuration files:")
    for file in CONFIG_FILES:
        if os.path.exists(file):
            # Create config directory if needed
            config_dir = os.path.join(DIST_FOLDER, "config")
            os.makedirs(config_dir, exist_ok=True)
            shutil.copy2(file, config_dir)
            print(f"  ✓ {file}")
        else:
            print(f"  ✗ {file} (not found)")
    
    # Copy documentation files
    print("\nCopying documentation files:")
    for file in DOC_FILES:
        if os.path.exists(file):
            # Create docs directory if needed
            docs_dir = os.path.join(DIST_FOLDER, "docs")
            os.makedirs(docs_dir, exist_ok=True)
            shutil.copy2(file, docs_dir)
            print(f"  ✓ {file}")
        else:
            print(f"  ✗ {file} (not found)")
    
    # Copy utility files
    print("\nCopying utility files:")
    for file in UTILS_FILES:
        if os.path.exists(file):
            # Create utils directory if needed
            utils_dir = os.path.join(DIST_FOLDER, "utils")
            os.makedirs(utils_dir, exist_ok=True)
            shutil.copy2(file, utils_dir)
            print(f"  ✓ {file}")
        else:
            print(f"  ✗ {file} (not found)")
    
    # Copy script files
    print("\nCopying script files:")
    for file in SCRIPT_FILES:
        if os.path.exists(file):
            # Create scripts directory if needed
            scripts_dir = os.path.join(DIST_FOLDER, "scripts")
            os.makedirs(scripts_dir, exist_ok=True)
            shutil.copy2(file, scripts_dir)
            print(f"  ✓ {file}")
        else:
            print(f"  ✗ {file} (not found)")
    
    # Copy plugin files
    print("\nCopying plugin files:")
    for file in PLUGIN_FILES:
        if os.path.exists(file):
            # Create plugins directory if needed
            plugins_dir = os.path.join(DIST_FOLDER, "plugins")
            os.makedirs(plugins_dir, exist_ok=True)
            shutil.copy2(file, plugins_dir)
            print(f"  ✓ {file}")
        else:
            print(f"  ✗ {file} (not found)")
    
    # Copy static files
    print("\nCopying static files:")
    for file in STATIC_FILES:
        if os.path.exists(file):
            # Create static directory structure if needed
            static_dir = os.path.join(DIST_FOLDER, "static")
            if file.startswith("static/css/"):
                css_dir = os.path.join(static_dir, "css")
                os.makedirs(css_dir, exist_ok=True)
                shutil.copy2(file, css_dir)
            elif file.startswith("static/js/"):
                js_dir = os.path.join(static_dir, "js")
                os.makedirs(js_dir, exist_ok=True)
                shutil.copy2(file, js_dir)
            print(f"  ✓ {file}")
        else:
            print(f"  ✗ {file} (not found)")
    
    # Copy template files
    print("\nCopying template files:")
    for file in TEMPLATE_FILES:
        if os.path.exists(file):
            # Create templates directory if needed
            templates_dir = os.path.join(DIST_FOLDER, "templates")
            os.makedirs(templates_dir, exist_ok=True)
            shutil.copy2(file, templates_dir)
            print(f"  ✓ {file}")
        else:
            print(f"  ✗ {file} (not found)")
    
    # Copy AI tools files
    print("\nCopying AI tools files:")
    for file in AI_TOOLS_FILES:
        if os.path.exists(file):
            # Create ai_tools directory structure if needed
            ai_tools_dir = os.path.join(DIST_FOLDER, "ai_tools")
            if file.startswith("ai_tools/ollama/"):
                ollama_dir = os.path.join(ai_tools_dir, "ollama")
                os.makedirs(ollama_dir, exist_ok=True)
                shutil.copy2(file, ollama_dir)
            elif file.startswith("ai_tools/oobabooga/"):
                oobabooga_dir = os.path.join(ai_tools_dir, "oobabooga")
                os.makedirs(oobabooga_dir, exist_ok=True)
                shutil.copy2(file, oobabooga_dir)
            elif file.startswith("ai_tools/rvc/"):
                rvc_dir = os.path.join(ai_tools_dir, "rvc")
                os.makedirs(rvc_dir, exist_ok=True)
                shutil.copy2(file, rvc_dir)
            elif file.startswith("ai_tools/zwaifu/"):
                zwaifu_dir = os.path.join(ai_tools_dir, "zwaifu")
                os.makedirs(zwaifu_dir, exist_ok=True)
                shutil.copy2(file, zwaifu_dir)
            print(f"  ✓ {file}")
        else:
            print(f"  ✗ {file} (not found)")
    
    # Copy data files
    print("\nCopying data files:")
    for file in DATA_FILES:
        if os.path.exists(file):
            # Create data directory if needed
            data_dir = os.path.join(DIST_FOLDER, "data")
            os.makedirs(data_dir, exist_ok=True)
            shutil.copy2(file, data_dir)
            print(f"  ✓ {file}")
        else:
            print(f"  ✗ {file} (not found)")
    
    # Copy optional files
    print("\nCopying optional files:")
    for file in OPTIONAL_FILES:
        if os.path.exists(file):
            shutil.copy2(file, DIST_FOLDER)
            print(f"  ✓ {file}")
        else:
            print(f"  - {file} (not found, skipping)")
    
    # Create additional distribution files
    print("\nCreating distribution files:")
    
    # Create version info file
    version_info = f"""Z-Waifu Launcher GUI
Version: {VERSION}
Build Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
Python Version: {sys.version.split()[0]}

This distribution contains:
- Main launcher application (zwaifu_launcher_gui.py)
- Smart launcher with dependency checking (launch_launcher.py)
- Windows batch launcher (launch_launcher.bat)
- Complete utility modules (utils/)
- Plugin system (plugins/)
- Web interface and templates (static/, templates/)
- AI tools configuration (ai_tools/)
- Complete documentation (docs/)
- Test suite (scripts/)
- Configuration files (config/)

Installation:
1. Extract this zip file
2. Double-click launch_launcher.bat to start
3. Or run: python launch_launcher.py

For detailed installation instructions, see docs/INSTALLATION_GUIDE.md
"""
    
    with open(os.path.join(DIST_FOLDER, "VERSION.txt"), "w", encoding="utf-8") as f:
        f.write(version_info)
    print("  ✓ VERSION.txt")
    
    # Create quick start guide
    quick_start = """QUICK START GUIDE
================

1. INSTALLATION
   - Extract this zip file to any folder
   - No installation required - just extract and run

2. FIRST LAUNCH
   - Double-click: launch_launcher.bat
   - Or run: python launch_launcher.py
   - The launcher will automatically install dependencies

3. CONFIGURATION
   - Go to Settings tab
   - Browse and select your batch files:
     * Oobabooga: text-generation-webui-main/start_windows.bat
     * Z-Waifu: z-waif-1.14-R4/startup.bat
   - Set your preferred ports
   - Click "Save Settings"

4. USAGE
   - Main tab: Start/stop all processes
   - Individual tabs: Launch multiple instances
   - Instance Manager: Monitor all running instances
   - CMD Flags: Edit Oobabooga command line flags
   - Advanced tab: Web interface, API server, mobile app

5. FEATURES
   - Multiple process instances
   - Embedded terminal with ANSI colors
   - Command history and input
   - Real-time process monitoring
   - Light/dark themes
   - Web-based management interface
   - REST API for automation
   - Mobile-optimized interface
   - Analytics and performance monitoring
   - Plugin system for extensibility

6. ADVANCED FEATURES
   - Web Interface: http://localhost:8080
   - API Server: http://localhost:8081/api
   - Mobile App: http://localhost:8082
   - Analytics Dashboard: View performance metrics
   - Plugin Management: Extend functionality

For detailed instructions, see docs/INSTALLATION_GUIDE.md
"""
    
    with open(os.path.join(DIST_FOLDER, "QUICK_START.txt"), "w", encoding="utf-8") as f:
        f.write(quick_start)
    print("  ✓ QUICK_START.txt")
    
    # Create system requirements file
    requirements_info = """SYSTEM REQUIREMENTS
===================

Minimum Requirements:
- Windows 10/11
- Python 3.7 or higher
- 4GB RAM
- 100MB disk space

Recommended Requirements:
- Windows 10/11
- Python 3.8 or higher
- 8GB RAM
- 500MB disk space
- Internet connection for dependency installation

Supported AI Tools:
- Oobabooga (text-generation-webui)
- Z-Waifu (character AI)
- Ollama (local LLMs)
- RVC (voice cloning)

For detailed requirements, see docs/INSTALLATION_GUIDE.md
"""
    
    with open(os.path.join(DIST_FOLDER, "REQUIREMENTS.txt"), "w", encoding="utf-8") as f:
        f.write(requirements_info)
    print("  ✓ REQUIREMENTS.txt")
    
    # Create advanced features guide
    advanced_guide = """ADVANCED FEATURES GUIDE
========================

WEB INTERFACE
-------------
- Access: http://localhost:8080
- Features: Browser-based management
- Real-time WebSocket updates
- Process control and monitoring
- Terminal access via web
- Responsive mobile design

REST API
--------
- Access: http://localhost:8081/api
- Features: Complete REST API
- API key authentication
- Rate limiting
- JSON responses
- Automation support

MOBILE APP
----------
- Access: http://localhost:8082
- Features: Mobile-optimized interface
- QR code for easy access
- Touch-friendly controls
- Responsive design

ANALYTICS SYSTEM
----------------
- Performance monitoring
- CPU and memory usage tracking
- Process uptime statistics
- Historical data analysis
- Export capabilities

PLUGIN SYSTEM
-------------
- Extensible architecture
- Custom plugin development
- Hot-reload capability
- Event-driven design
- Documentation included

USAGE EXAMPLES
--------------

1. Start Advanced Features:
   - Go to Advanced tab
   - Click "Start Web Interface"
   - Click "Start API Server"
   - Click "Start Mobile App"

2. Access Web Interface:
   - Open browser to http://localhost:8080
   - Monitor and control processes
   - View real-time status

3. Use REST API:
   - GET /api/status - Get system status
   - POST /api/start/Oobabooga - Start process
   - POST /api/stop/Z-Waifu - Stop process

4. Mobile Access:
   - Scan QR code from Advanced tab
   - Or visit http://localhost:8082
   - Use touch controls

5. View Analytics:
   - Click "View Analytics" in Advanced tab
   - Monitor performance metrics
   - Generate reports

For more information, see the documentation in the docs/ directory.
"""
    
    with open(os.path.join(DIST_FOLDER, "ADVANCED_FEATURES.txt"), "w", encoding="utf-8") as f:
        f.write(advanced_guide)
    print("  ✓ ADVANCED_FEATURES.txt")
    
    # Create zip file
    zip_filename = f"{DIST_FOLDER}.zip"
    print(f"\nCreating zip file: {zip_filename}")
    
    with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(DIST_FOLDER):
            for file in files:
                file_path = os.path.join(root, file)
                arc_name = os.path.relpath(file_path, DIST_FOLDER)
                zipf.write(file_path, arc_name)
                print(f"  ✓ Added: {arc_name}")
    
    # Clean up distribution folder
    print(f"\nCleaning up distribution folder: {DIST_FOLDER}")
    shutil.rmtree(DIST_FOLDER)
    
    # Final summary
    print(f"\nDistribution created successfully!")
    print(f"Zip file: {zip_filename}")
    print(f"Size: {os.path.getsize(zip_filename) / 1024:.1f} KB")
    
    # List contents
    print(f"\nDistribution contents:")
    with zipfile.ZipFile(zip_filename, 'r') as zipf:
        for info in zipf.infolist():
            print(f"  - {info.filename}")
    
    print(f"\nReady for distribution! 🚀")
    return zip_filename

def create_minimal_distribution():
    """Create a minimal distribution with only essential files"""
    
    # Distribution name and version
    DIST_NAME = "Z-Waifu-Launcher-GUI-Minimal"
    VERSION = "1.1.0"  # Updated version
    DIST_FOLDER = f"{DIST_NAME}-v{VERSION}"
    
    # Essential files only
    ESSENTIAL_FILES = [
        "zwaifu_launcher_gui.py",
        "launch_launcher.py",
        "launch_launcher.bat",
        "config/requirements.txt",
        "README.md"
    ]
    
    print(f"Creating minimal distribution: {DIST_NAME} v{VERSION}")
    print("=" * 50)
    
    # Create distribution directory
    if os.path.exists(DIST_FOLDER):
        print(f"Removing existing distribution folder: {DIST_FOLDER}")
        shutil.rmtree(DIST_FOLDER)
    
    os.makedirs(DIST_FOLDER)
    print(f"Created distribution folder: {DIST_FOLDER}")
    
    # Copy essential files
    print("\nCopying essential files:")
    for file in ESSENTIAL_FILES:
        if os.path.exists(file):
            # Handle config directory
            if file.startswith("config/"):
                config_dir = os.path.join(DIST_FOLDER, "config")
                os.makedirs(config_dir, exist_ok=True)
                shutil.copy2(file, config_dir)
            else:
                shutil.copy2(file, DIST_FOLDER)
            print(f"  ✓ {file}")
        else:
            print(f"  ✗ {file} (not found)")
    
    # Create minimal readme
    minimal_readme = """Z-Waifu Launcher GUI - Minimal Distribution
===============================================

This is a minimal distribution containing only the essential files.

QUICK START:
1. Double-click: launch_launcher.bat
2. Or run: python launch_launcher.py
3. Configure your batch files in Settings tab

FEATURES INCLUDED:
- Main launcher application
- Smart dependency installation
- Basic process management
- Settings configuration
- Light/dark themes

ADVANCED FEATURES NOT INCLUDED:
- Web interface
- REST API server
- Mobile app
- Analytics system
- Plugin system

For full features and documentation, 
download the complete distribution.
"""
    
    with open(os.path.join(DIST_FOLDER, "README.txt"), "w", encoding="utf-8") as f:
        f.write(minimal_readme)
    print("  ✓ README.txt")
    
    # Create zip file
    zip_filename = f"{DIST_FOLDER}.zip"
    print(f"\nCreating zip file: {zip_filename}")
    
    with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(DIST_FOLDER):
            for file in files:
                file_path = os.path.join(root, file)
                arc_name = os.path.relpath(file_path, DIST_FOLDER)
                zipf.write(file_path, arc_name)
                print(f"  ✓ Added: {arc_name}")
    
    # Clean up
    shutil.rmtree(DIST_FOLDER)
    
    print(f"\nMinimal distribution created: {zip_filename}")
    print(f"Size: {os.path.getsize(zip_filename) / 1024:.1f} KB")
    return zip_filename

def main():
    """Main function"""
    print("Z-Waifu Launcher GUI - Distribution Creator")
    print("=" * 50)
    
    if len(sys.argv) > 1 and sys.argv[1] == "--minimal":
        create_minimal_distribution()
    else:
        create_distribution()

if __name__ == "__main__":
    main() 